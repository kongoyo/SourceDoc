/*
 * Adapted from http://www.zlib.net/zlib_how.html
 **/

#ifndef BARFLATE_H_
#define BARFLATE_H_

#include <stdio.h>

int inf(FILE *source, FILE *dest);

#endif
